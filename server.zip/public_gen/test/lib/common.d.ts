/// <reference path="../../../public/app/headers/common.d.ts" />
declare var beforeEach: any;
declare var before: any;
declare var describe: any;
declare var it: any;
declare var sinon: any;
declare var expect: any;
declare var angularMocks: {
    module: any;
    inject: any;
};
export { beforeEach, before, describe, it, sinon, expect, angularMocks };
