///<reference path="../../headers/common.d.ts" />
System.register(['angular'], function(exports_1) {
    var angular_1;
    /** @ngInject */
    function metricsQueryEditor(dynamicDirectiveSrv, datasourceSrv) {
        return dynamicDirectiveSrv.create({
            watchPath: "panel.datasource",
            directive: function (scope) {
                var datasource = scope.target.datasource || scope.panel.datasource;
                return datasourceSrv.get(datasource).then(function (ds) {
                    scope.datasource = ds;
                    if (!scope.target.refId) {
                        scope.target.refId = 'A';
                    }
                    return System.import(ds.meta.module).then(function (dsModule) {
                        return {
                            name: 'metrics-query-editor-' + ds.meta.id,
                            fn: dsModule.metricsQueryEditor,
                        };
                    });
                });
            }
        });
    }
    /** @ngInject */
    function metricsQueryOptions(dynamicDirectiveSrv, datasourceSrv) {
        return dynamicDirectiveSrv.create({
            watchPath: "panel.datasource",
            directive: function (scope) {
                return datasourceSrv.get(scope.panel.datasource).then(function (ds) {
                    return System.import(ds.meta.module).then(function (dsModule) {
                        return {
                            name: 'metrics-query-options-' + ds.meta.id,
                            fn: dsModule.metricsQueryOptions
                        };
                    });
                });
            }
        });
    }
    return {
        setters:[
            function (angular_1_1) {
                angular_1 = angular_1_1;
            }],
        execute: function() {
            angular_1.default.module('grafana.directives')
                .directive('metricsQueryEditor', metricsQueryEditor)
                .directive('metricsQueryOptions', metricsQueryOptions);
        }
    }
});
//# sourceMappingURL=query_editor.js.map