///<reference path="../../headers/common.d.ts" />
System.register(['angular', 'app/core/config'], function(exports_1) {
    var angular_1, config_1;
    /** @ngInject */
    function panelLoader($parse, dynamicDirectiveSrv) {
        return dynamicDirectiveSrv.create({
            directive: function (scope) {
                var modulePath = config_1.default.panels[scope.panel.type].module;
                return System.import(modulePath).then(function (panelModule) {
                    return {
                        name: 'panel-directive-' + scope.panel.type,
                        fn: panelModule.panel,
                    };
                });
            },
        });
    }
    return {
        setters:[
            function (angular_1_1) {
                angular_1 = angular_1_1;
            },
            function (config_1_1) {
                config_1 = config_1_1;
            }],
        execute: function() {
            angular_1.default.module('grafana.directives').directive('panelLoader', panelLoader);
        }
    }
});
//# sourceMappingURL=panel_loader.js.map