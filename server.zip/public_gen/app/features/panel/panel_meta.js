define([
  './panel_meta2',
],
function (panelMeta) {
  'use strict';
  return panelMeta.default;
});
