define([
  './panellinks/module',
  './dashlinks/module',
  './annotations/annotations_srv',
  './templating/templateSrv',
  './dashboard/all',
  './playlist/all',
  './panel/all',
  './profile/profileCtrl',
  './profile/changePasswordCtrl',
  './profile/selectOrgCtrl',
  './admin/all',
], function () {});
