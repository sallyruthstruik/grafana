define([
  './list_ctrl',
  './edit_ctrl',
  './config_view',
], function () {});
