///<reference path="../../headers/common.d.ts" />
System.register(['angular'], function(exports_1) {
    var angular_1;
    /** @ngInject */
    function dsConfigView(dynamicDirectiveSrv) {
        return dynamicDirectiveSrv.create({
            scope: {
                dsMeta: "=",
                current: "="
            },
            watchPath: "dsMeta.module",
            directive: function (scope) {
                return System.import(scope.dsMeta.module).then(function (dsModule) {
                    return {
                        name: 'ds-config-' + scope.dsMeta.id,
                        fn: dsModule.configView,
                    };
                });
            },
        });
    }
    return {
        setters:[
            function (angular_1_1) {
                angular_1 = angular_1_1;
            }],
        execute: function() {
            angular_1.default.module('grafana.directives').directive('dsConfigView', dsConfigView);
        }
    }
});
//# sourceMappingURL=config_view.js.map