define([
  './playlists_ctrl',
  './playlistSrv',
  './playlist_edit_ctrl',
  './playlist_routes'
], function () {});
