System.register(['../playlist_edit_ctrl', 'test/lib/common', 'test/specs/helpers'], function(exports_1) {
    var common_1, helpers_1;
    return {
        setters:[
            function (_1) {},
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (helpers_1_1) {
                helpers_1 = helpers_1_1;
            }],
        execute: function() {
            common_1.describe('PlaylistEditCtrl', function () {
                var ctx = new helpers_1.default.ControllerTestContext();
                var searchResult = [
                    {
                        id: 2,
                        title: 'dashboard: 2'
                    },
                    {
                        id: 3,
                        title: 'dashboard: 3'
                    }
                ];
                var playlistSrv = {};
                var backendSrv = {
                    search: function (query) {
                        return ctx.$q.when(searchResult);
                    }
                };
                common_1.beforeEach(common_1.angularMocks.module('grafana.core'));
                common_1.beforeEach(common_1.angularMocks.module('grafana.controllers'));
                common_1.beforeEach(common_1.angularMocks.module('grafana.services'));
                common_1.beforeEach(ctx.providePhase({
                    playlistSrv: playlistSrv,
                    backendSrv: backendSrv,
                    $route: { current: { params: {} } },
                }));
                common_1.beforeEach(ctx.createControllerPhase('PlaylistEditCtrl'));
                common_1.beforeEach(function () {
                    ctx.scope.$digest();
                });
                common_1.describe('searchresult returns 2 dashboards', function () {
                    common_1.it('found dashboard should be 2', function () {
                        common_1.expect(ctx.scope.foundPlaylistItems.length).to.be(2);
                    });
                    common_1.it('filtred dashboard should be 2', function () {
                        common_1.expect(ctx.scope.filteredPlaylistItems.length).to.be(2);
                    });
                    common_1.describe('adds one dashboard to playlist', function () {
                        common_1.beforeEach(function () {
                            ctx.scope.addPlaylistItem({ id: 2, title: 'dashboard: 2' });
                        });
                        common_1.it('playlistitems should be increased by one', function () {
                            common_1.expect(ctx.scope.playlistItems.length).to.be(1);
                        });
                        common_1.it('filtred playlistitems should be reduced by one', function () {
                            common_1.expect(ctx.scope.filteredPlaylistItems.length).to.be(1);
                        });
                        common_1.it('found dashboard should be 2', function () {
                            common_1.expect(ctx.scope.foundPlaylistItems.length).to.be(2);
                        });
                        common_1.describe('removes one dashboard from playlist', function () {
                            common_1.beforeEach(function () {
                                ctx.scope.removePlaylistItem(ctx.scope.playlistItems[0]);
                            });
                            common_1.it('playlistitems should be increased by one', function () {
                                common_1.expect(ctx.scope.playlistItems.length).to.be(0);
                            });
                            common_1.it('found dashboard should be 2', function () {
                                common_1.expect(ctx.scope.foundPlaylistItems.length).to.be(2);
                            });
                            common_1.it('filtred playlist should be reduced by one', function () {
                                common_1.expect(ctx.scope.filteredPlaylistItems.length).to.be(2);
                            });
                        });
                    });
                });
            });
        }
    }
});
//# sourceMappingURL=playlist-edit-ctrl-specs.js.map