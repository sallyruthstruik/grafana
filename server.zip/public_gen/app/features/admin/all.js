define([
  './adminListUsersCtrl',
  './adminListOrgsCtrl',
  './adminEditOrgCtrl',
  './adminEditUserCtrl',
  './adminSettingsCtrl',
], function () {});
