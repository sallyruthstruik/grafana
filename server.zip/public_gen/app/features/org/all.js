define([
  './orgUsersCtrl',
  './newOrgCtrl',
  './userInviteCtrl',
  './orgApiKeysCtrl',
  './orgDetailsCtrl',
  '../datasources/all',
], function () {});
