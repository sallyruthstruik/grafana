System.register(['./edit_ctrl', './list_ctrl', './config_view'], function(exports_1) {
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {}],
        execute: function() {
        }
    }
});
//# sourceMappingURL=all.js.map