///<reference path="../../headers/common.d.ts" />
System.register(['angular'], function(exports_1) {
    var angular_1;
    /** @ngInject */
    function appConfigView(dynamicDirectiveSrv) {
        return dynamicDirectiveSrv.create({
            scope: {
                appModel: "="
            },
            directive: function (scope) {
                return System.import(scope.appModel.module).then(function (appModule) {
                    return {
                        name: 'app-config-' + scope.appModel.appId,
                        fn: appModule.configView,
                    };
                });
            },
        });
    }
    return {
        setters:[
            function (angular_1_1) {
                angular_1 = angular_1_1;
            }],
        execute: function() {
            angular_1.default.module('grafana.directives').directive('appConfigView', appConfigView);
        }
    }
});
//# sourceMappingURL=config_view.js.map