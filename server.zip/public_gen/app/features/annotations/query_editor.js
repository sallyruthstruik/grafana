///<reference path="../../headers/common.d.ts" />
System.register(['angular'], function(exports_1) {
    var angular_1;
    /** @ngInject */
    function annotationsQueryEditor(dynamicDirectiveSrv) {
        return dynamicDirectiveSrv.create({
            scope: {
                annotation: "=",
                datasource: "="
            },
            watchPath: "datasource.type",
            directive: function (scope) {
                return System.import(scope.datasource.meta.module).then(function (dsModule) {
                    return {
                        name: 'annotation-query-editor-' + scope.datasource.meta.id,
                        fn: dsModule.annotationsQueryEditor,
                    };
                });
            },
        });
    }
    return {
        setters:[
            function (angular_1_1) {
                angular_1 = angular_1_1;
            }],
        execute: function() {
            angular_1.default.module('grafana.directives').directive('annotationsQueryEditor', annotationsQueryEditor);
        }
    }
});
//# sourceMappingURL=query_editor.js.map