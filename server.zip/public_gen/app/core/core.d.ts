/// <reference path="../../../public/app/headers/common.d.ts" />
/// <reference path="../../../public/app/core/mod_defs.d.ts" />
import { arrayJoin } from './directives/array_join';
import coreModule from './core_module';
export { arrayJoin, coreModule };
