export default function flatten(target: any, opts: any): any;
