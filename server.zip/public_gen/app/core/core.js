///<reference path="../headers/common.d.ts" />
///<reference path="./mod_defs.d.ts" />
System.register(["./directives/annotation_tooltip", "./directives/body_class", "./directives/config_modal", "./directives/confirm_click", "./directives/dash_edit_link", "./directives/dash_upload", "./directives/dropdown_typeahead", "./directives/grafana_version_check", "./directives/metric_segment", "./directives/misc", "./directives/ng_model_on_blur", "./directives/password_strenght", "./directives/spectrum_picker", "./directives/tags", "./directives/topnav", "./directives/value_select_dropdown", "./directives/give_focus", './jquery_extended', './partials', './directives/array_join', 'app/core/controllers/all', 'app/core/services/all', 'app/core/routes/all', './filters/filters', './core_module'], function(exports_1) {
    var array_join_1, core_module_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (_6) {},
            function (_7) {},
            function (_8) {},
            function (_9) {},
            function (_10) {},
            function (_11) {},
            function (_12) {},
            function (_13) {},
            function (_14) {},
            function (_15) {},
            function (_16) {},
            function (_17) {},
            function (_18) {},
            function (_19) {},
            function (array_join_1_1) {
                array_join_1 = array_join_1_1;
            },
            function (_20) {},
            function (_21) {},
            function (_22) {},
            function (_23) {},
            function (core_module_1_1) {
                core_module_1 = core_module_1_1;
            }],
        execute: function() {
            exports_1("arrayJoin", array_join_1.arrayJoin);
            exports_1("coreModule", core_module_1.default);
        }
    }
});
//# sourceMappingURL=core.js.map