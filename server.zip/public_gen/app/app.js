define([
  './grafana'
], function(app) {
  'use strict';
  // backward compatability hack;
  return app.default;
});
