/// <reference path="../../public/app/headers/common.d.ts" />
export declare class GrafanaApp {
    registerFunctions: any;
    ngModuleDependencies: any[];
    preBootModules: any[];
    constructor();
    useModule(module: any): any;
    init(): void;
}
declare var _default: GrafanaApp;
export default _default;
