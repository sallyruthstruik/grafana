///<reference path="../../../headers/common.d.ts" />
System.register(['lodash', 'angular', './transformers', 'app/core/utils/kbn'], function(exports_1) {
    var lodash_1, angular_1, transformers_1, kbn_1;
    var TablePanelEditorCtrl;
    /** @ngInject */
    function tablePanelEditor($q, uiSegmentSrv) {
        'use strict';
        return {
            restrict: 'E',
            scope: true,
            templateUrl: 'app/plugins/panel/table/editor.html',
            controller: TablePanelEditorCtrl,
        };
    }
    exports_1("tablePanelEditor", tablePanelEditor);
    return {
        setters:[
            function (lodash_1_1) {
                lodash_1 = lodash_1_1;
            },
            function (angular_1_1) {
                angular_1 = angular_1_1;
            },
            function (transformers_1_1) {
                transformers_1 = transformers_1_1;
            },
            function (kbn_1_1) {
                kbn_1 = kbn_1_1;
            }],
        execute: function() {
            TablePanelEditorCtrl = (function () {
                /** @ngInject */
                function TablePanelEditorCtrl($scope, $q, uiSegmentSrv) {
                    $scope.transformers = transformers_1.transformers;
                    $scope.unitFormats = kbn_1.default.getUnitFormats();
                    $scope.colorModes = [
                        { text: 'Disabled', value: null },
                        { text: 'Cell', value: 'cell' },
                        { text: 'Value', value: 'value' },
                        { text: 'Row', value: 'row' },
                    ];
                    $scope.columnTypes = [
                        { text: 'Number', value: 'number' },
                        { text: 'String', value: 'string' },
                        { text: 'Date', value: 'date' },
                    ];
                    $scope.fontSizes = ['80%', '90%', '100%', '110%', '120%', '130%', '150%', '160%', '180%', '200%', '220%', '250%'];
                    $scope.dateFormats = [
                        { text: 'YYYY-MM-DD HH:mm:ss', value: 'YYYY-MM-DD HH:mm:ss' },
                        { text: 'MM/DD/YY h:mm:ss a', value: 'MM/DD/YY h:mm:ss a' },
                        { text: 'MMMM D, YYYY LT', value: 'MMMM D, YYYY LT' },
                    ];
                    $scope.addColumnSegment = uiSegmentSrv.newPlusButton();
                    $scope.getColumnOptions = function () {
                        if (!$scope.dataRaw) {
                            return $q.when([]);
                        }
                        var columns = transformers_1.transformers[$scope.panel.transform].getColumns($scope.dataRaw);
                        var segments = lodash_1.default.map(columns, function (c) { return uiSegmentSrv.newSegment({ value: c.text }); });
                        return $q.when(segments);
                    };
                    $scope.addColumn = function () {
                        var columns = transformers_1.transformers[$scope.panel.transform].getColumns($scope.dataRaw);
                        var column = lodash_1.default.findWhere(columns, { text: $scope.addColumnSegment.value });
                        if (column) {
                            $scope.panel.columns.push(column);
                            $scope.render();
                        }
                        var plusButton = uiSegmentSrv.newPlusButton();
                        $scope.addColumnSegment.html = plusButton.html;
                        $scope.addColumnSegment.value = plusButton.value;
                    };
                    $scope.transformChanged = function () {
                        $scope.panel.columns = [];
                        $scope.render();
                    };
                    $scope.removeColumn = function (column) {
                        $scope.panel.columns = lodash_1.default.without($scope.panel.columns, column);
                        $scope.render();
                    };
                    $scope.setUnitFormat = function (column, subItem) {
                        column.unit = subItem.value;
                        $scope.render();
                    };
                    $scope.addColumnStyle = function () {
                        var columnStyleDefaults = {
                            unit: 'short',
                            type: 'number',
                            decimals: 2,
                            colors: ["rgba(245, 54, 54, 0.9)", "rgba(237, 129, 40, 0.89)", "rgba(50, 172, 45, 0.97)"],
                            colorMode: null,
                            pattern: '/.*/',
                            dateFormat: 'YYYY-MM-DD HH:mm:ss',
                            thresholds: [],
                        };
                        $scope.panel.styles.push(angular_1.default.copy(columnStyleDefaults));
                    };
                    $scope.removeColumnStyle = function (style) {
                        $scope.panel.styles = lodash_1.default.without($scope.panel.styles, style);
                    };
                    $scope.getColumnNames = function () {
                        if (!$scope.table) {
                            return [];
                        }
                        return lodash_1.default.map($scope.table.columns, function (col) {
                            return col.text;
                        });
                    };
                    $scope.invertColorOrder = function (index) {
                        var ref = $scope.panel.styles[index].colors;
                        var copy = ref[0];
                        ref[0] = ref[2];
                        ref[2] = copy;
                        $scope.render();
                    };
                }
                return TablePanelEditorCtrl;
            })();
            exports_1("TablePanelEditorCtrl", TablePanelEditorCtrl);
        }
    }
});
//# sourceMappingURL=editor.js.map