declare var panel: any;
declare var GraphCtrl: any;
export {panel, GraphCtrl};
