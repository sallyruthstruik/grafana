///<reference path="../../../../headers/common.d.ts" />
System.register(['../../../../../test/lib/common', 'app/features/panel/panel_srv', 'app/features/panel/panel_helper', 'angular', '../module', '../../../../../test/specs/helpers'], function(exports_1) {
    var common_1, angular_1, module_1, helpers_1;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (_1) {},
            function (_2) {},
            function (angular_1_1) {
                angular_1 = angular_1_1;
            },
            function (module_1_1) {
                module_1 = module_1_1;
            },
            function (helpers_1_1) {
                helpers_1 = helpers_1_1;
            }],
        execute: function() {
            angular_1.default.module('grafana.controllers').controller('GraphCtrl', module_1.GraphCtrl);
            common_1.describe('GraphCtrl', function () {
                var ctx = new helpers_1.default.ControllerTestContext();
                common_1.beforeEach(common_1.angularMocks.module('grafana.services'));
                common_1.beforeEach(common_1.angularMocks.module('grafana.controllers'));
                common_1.beforeEach(ctx.providePhase());
                common_1.beforeEach(ctx.createControllerPhase('GraphCtrl'));
                common_1.describe('get_data with 2 series', function () {
                    common_1.beforeEach(function () {
                        ctx.annotationsSrv.getAnnotations = common_1.sinon.stub().returns(ctx.$q.when([]));
                        ctx.datasource.query = common_1.sinon.stub().returns(ctx.$q.when({
                            data: [
                                { target: 'test.cpu1', datapoints: [[1, 10]] },
                                { target: 'test.cpu2', datapoints: [[1, 10]] }
                            ]
                        }));
                        ctx.scope.render = common_1.sinon.spy();
                        ctx.scope.refreshData(ctx.datasource);
                        ctx.scope.$digest();
                    });
                    common_1.it('should send time series to render', function () {
                        var data = ctx.scope.render.getCall(0).args[0];
                        common_1.expect(data.length).to.be(2);
                    });
                    common_1.describe('get_data failure following success', function () {
                        common_1.beforeEach(function () {
                            ctx.datasource.query = common_1.sinon.stub().returns(ctx.$q.reject('Datasource Error'));
                            ctx.scope.refreshData(ctx.datasource);
                            ctx.scope.$digest();
                        });
                    });
                });
            });
        }
    }
});
//# sourceMappingURL=graph_ctrl_specs.js.map