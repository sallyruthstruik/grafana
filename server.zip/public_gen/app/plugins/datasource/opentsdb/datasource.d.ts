declare var Datasource: any;
export default Datasource;

