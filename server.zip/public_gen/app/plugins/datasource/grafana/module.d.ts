/// <reference path="../../../../../public/app/headers/common.d.ts" />
import { GrafanaDatasource } from './datasource';
declare function grafanaMetricsQueryEditor(): {
    templateUrl: string;
};
export { GrafanaDatasource, GrafanaDatasource as Datasource, grafanaMetricsQueryEditor as metricsQueryEditor };
