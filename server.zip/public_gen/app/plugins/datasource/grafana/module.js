///<reference path="../../../headers/common.d.ts" />
System.register(['angular', './datasource'], function(exports_1) {
    var angular_1, datasource_1;
    var module;
    function grafanaMetricsQueryEditor() {
        return { templateUrl: 'app/plugins/datasource/grafana/partials/query.editor.html' };
    }
    return {
        setters:[
            function (angular_1_1) {
                angular_1 = angular_1_1;
            },
            function (datasource_1_1) {
                datasource_1 = datasource_1_1;
            }],
        execute: function() {
            module = angular_1.default.module('grafana.directives');
            exports_1("GrafanaDatasource", datasource_1.GrafanaDatasource);
            exports_1("Datasource", datasource_1.GrafanaDatasource);
            exports_1("metricsQueryEditor", grafanaMetricsQueryEditor);
        }
    }
});
//# sourceMappingURL=module.js.map