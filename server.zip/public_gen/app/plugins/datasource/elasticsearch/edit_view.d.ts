/// <reference path="../../../../../public/app/headers/common.d.ts" />
export declare class EditViewCtrl {
    constructor($scope: any);
}
declare function editViewDirective(): {
    templateUrl: string;
    controller: typeof EditViewCtrl;
};
export default editViewDirective;
