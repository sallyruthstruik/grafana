///<amd-dependency path="../query_ctrl" />
///<amd-dependency path="app/core/services/segment_srv" />
///<amd-dependency path="test/specs/helpers" name="helpers" />
System.register(['test/lib/common', 'test/specs/helpers'], function(exports_1) {
    var common_1, helpers_1;
    return {
        setters:[
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (helpers_1_1) {
                helpers_1 = helpers_1_1;
            }],
        execute: function() {
            common_1.describe('ElasticQueryCtrl', function () {
                var ctx = new helpers_1.default.ControllerTestContext();
                common_1.beforeEach(common_1.angularMocks.module('grafana.controllers'));
                common_1.beforeEach(common_1.angularMocks.module('grafana.services'));
                common_1.beforeEach(ctx.providePhase());
                common_1.beforeEach(ctx.createControllerPhase('ElasticQueryCtrl'));
                common_1.beforeEach(function () {
                    ctx.scope.target = {};
                    ctx.scope.$parent = { get_data: common_1.sinon.spy() };
                    ctx.scope.datasource = ctx.datasource;
                    ctx.scope.datasource.metricFindQuery = common_1.sinon.stub().returns(ctx.$q.when([]));
                });
                common_1.describe('init', function () {
                    common_1.beforeEach(function () {
                        ctx.scope.init();
                    });
                });
            });
        }
    }
});
//# sourceMappingURL=query_ctrl_specs.js.map