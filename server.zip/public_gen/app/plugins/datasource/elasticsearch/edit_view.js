///<reference path="../../../headers/common.d.ts" />
System.register(['lodash'], function(exports_1) {
    var lodash_1;
    var EditViewCtrl;
    function editViewDirective() {
        return {
            templateUrl: 'app/plugins/datasource/elasticsearch/partials/edit_view.html',
            controller: EditViewCtrl,
        };
    }
    return {
        setters:[
            function (lodash_1_1) {
                lodash_1 = lodash_1_1;
            }],
        execute: function() {
            EditViewCtrl = (function () {
                function EditViewCtrl($scope) {
                    $scope.indexPatternTypes = [
                        { name: 'No pattern', value: undefined },
                        { name: 'Hourly', value: 'Hourly', example: '[logstash-]YYYY.MM.DD.HH' },
                        { name: 'Daily', value: 'Daily', example: '[logstash-]YYYY.MM.DD' },
                        { name: 'Weekly', value: 'Weekly', example: '[logstash-]GGGG.WW' },
                        { name: 'Monthly', value: 'Monthly', example: '[logstash-]YYYY.MM' },
                        { name: 'Yearly', value: 'Yearly', example: '[logstash-]YYYY' },
                    ];
                    $scope.esVersions = [
                        { name: '1.x', value: 1 },
                        { name: '2.x', value: 2 },
                    ];
                    $scope.indexPatternTypeChanged = function () {
                        var def = lodash_1.default.findWhere($scope.indexPatternTypes, { value: $scope.current.jsonData.interval });
                        $scope.current.database = def.example || 'es-index-name';
                    };
                }
                return EditViewCtrl;
            })();
            exports_1("EditViewCtrl", EditViewCtrl);
            ;
            exports_1("default",editViewDirective);
        }
    }
});
//# sourceMappingURL=edit_view.js.map